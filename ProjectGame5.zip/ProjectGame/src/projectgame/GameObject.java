// Abstract Class for GameObject
package projectgame;

import javafx.scene.image.ImageView;

public abstract class GameObject {
    protected ImageView imageView;

    public GameObject(ImageView imageView) {
        this.imageView = imageView;
    }

    public ImageView getImageView() {
        return imageView;
    }

    public abstract void updatePosition();
}